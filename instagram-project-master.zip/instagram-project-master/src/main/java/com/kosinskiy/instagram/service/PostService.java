package com.kosinskiy.instagram.service;

import com.kosinskiy.instagram.dto.PostDto;
import com.kosinskiy.instagram.entity.Like;
import com.kosinskiy.instagram.entity.Post;
import com.kosinskiy.instagram.entity.User;
import com.kosinskiy.instagram.repository.PostRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.security.Principal;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Component
public class PostService {

	@Autowired
	private UserService userService;
	@Autowired
	private PostRepository postRepository;
	@Autowired
	private ModelMapper modelMapper;

	public List<Post> getPosts() {
		return postRepository.findAll();
	}

	private Post getPost(Long id) {
		return postRepository.findById(id).orElse(Post.builder().build());
	}

	public PostDto getPostDtoById(Long id) {
		return modelMapper.map(getPost(id), PostDto.class);
	}

	public void addOrRemoveIfExistLike(Principal principal, Long postId) {
		User principalUser = userService.getUserFromPrincipal(principal);
		Post post = getPost(postId);
		Optional<Like> principalLike = post.getLikes()
				.stream()
				.filter(like -> like.getUser().getId() == principalUser.getId())
				.findFirst();
		addOrRemoveLike(principalLike, post, principalUser);
		postRepository.save(post);
	}

	private void addOrRemoveLike(Optional<Like> principalLike, Post post, User user) {
		if (principalLike.isPresent()) {
			post.removeLike(principalLike.get());
		} else {
			post.addLike(user);
		}
	}
}
