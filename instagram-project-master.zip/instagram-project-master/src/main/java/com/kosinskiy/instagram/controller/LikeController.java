package com.kosinskiy.instagram.controller;

import com.kosinskiy.instagram.entity.Like;
import com.kosinskiy.instagram.service.LikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/like")
public class LikeController {

	@Autowired
	private LikeService likeService;

	@GetMapping("/post/{postId}")
	public List<Like> getLikesByPostId(@PathVariable Long postId) {
		return likeService.getLikesByPostId(postId);
	}

}
