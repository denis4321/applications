package com.kosinskiy.instagram.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "comments")
@Data
public class Comment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "date")
	private Date date;

	@Column(name = "text")
	private String text;

	@ManyToOne
	@JoinColumn(name = "post_id")
	@JsonBackReference
	private Post post;

	@OneToOne
	@JoinColumn(name = "user_id")
	@JsonManagedReference
	private User user;
}
