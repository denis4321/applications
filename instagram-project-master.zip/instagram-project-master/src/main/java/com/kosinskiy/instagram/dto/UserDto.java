package com.kosinskiy.instagram.dto;

import com.kosinskiy.instagram.entity.Post;
import com.kosinskiy.instagram.entity.User;
import lombok.Data;

import java.util.List;

@Data
public class UserDto {

	private long id;
	private String firstName;
	private String lastName;
	private String email;
	private String userName;
	private String photo;
	private List<Post> posts;
	private List<User> followers;
	private List<User> following;

}
