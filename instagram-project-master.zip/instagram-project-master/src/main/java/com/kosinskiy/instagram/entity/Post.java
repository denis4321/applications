package com.kosinskiy.instagram.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import java.util.Date;
import java.util.List;

@Entity
@Data
@Table(name = "posts")
public class Post {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private long id;

	@NotNull
	@PastOrPresent
	@Column(name = "date")
	private Date date;

	@Column(name = "text")
	private String text;

	@Column(name = "photo")
	private String photo;

	@ManyToOne(cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
	@JoinColumn(name = "user_id")
	@JsonBackReference
	private User user;

	@OneToMany(orphanRemoval = true, mappedBy = "post", cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<Like> likes;

	@OneToMany(mappedBy = "post")
	@JsonManagedReference
	private List<Comment> comments;

	public void addLike(User user) {
		Like like = new Like();
		like.setPost(this);
		like.setUser(user);
		this.likes.add(like);
	}

	public void removeLike(Like like) {
		this.likes.remove(like);
	}

	public static Post.Builder builder() {
		return new Post().new Builder();
	}

	public class Builder {

		private Builder() {}

		public Post.Builder date(Date date) {
			Post.this.date = date;
			return this;
		}

		public Post.Builder text(String text) {
			Post.this.text = text;
			return this;
		}

		public Post.Builder photo(String photo) {
			Post.this.photo = photo;
			return this;
		}

		public Post.Builder user(User user) {
			Post.this.user = user;
			return this;
		}

		public Post build() {
			return Post.this;
		}
	}
}
