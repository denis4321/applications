package com.kosinskiy.instagram.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.kosinskiy.instagram.validation.EmailExtended;
import com.kosinskiy.instagram.validation.UniqueEmail;
import com.kosinskiy.instagram.validation.UniqueUserName;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.Date;
import java.util.List;

@Data
@Entity
@Table(name = "users")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private long id;
	@Size(min = 2, message = "Too short first name")
	@Column(name = "first_name")
	private String firstName;
	@Size(min = 2, message = "Too short last name")
	@Column(name = "last_name")
	private String lastName;
	@EmailExtended
	@UniqueEmail
	@Column(name = "email")
	private String email;
	@Size(min = 2, message = "Too short login")
	@UniqueUserName
	@Column(name = "user_name")
	private String userName;
	@Size(min = 5, message = "Too short password")
	@Column(name = "password")
	@JsonIgnore
	private String password;
	@Column(name = "photo")
	private String photo;

	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Post> posts;

	@ManyToMany
	@JoinTable(
			name = "followers",
			joinColumns = @JoinColumn(name = "user"),
			inverseJoinColumns = @JoinColumn(name = "follower")
	)
	@JsonIgnore
	private List<User> followers;

	@ManyToMany
	@JoinTable(
			name = "followers",
			joinColumns = @JoinColumn(name = "follower"),
			inverseJoinColumns = @JoinColumn(name = "user")
	)
	@JsonIgnore
	private List<User> following;

	@ManyToMany
	@JoinTable(
			name = "user_chats",
			joinColumns = @JoinColumn (name ="user_id"),
			inverseJoinColumns = @JoinColumn(name = "chat_id"))
	@JsonIgnore
	private List<Chat> chats;

	public void addFollowing(User user) {
		this.following.add(user);
	}

	public void addPost(String postText, String fileName) {
		this.posts.add(Post.builder()
				.date(new Date())
				.text(postText)
				.photo(fileName)
				.user(this)
				.build());
	}

	public void removeFollowing(User user) {
		this.following.remove(user);
	}

	public static Builder builder() {
		return new User().new Builder();
	}

	public class Builder {

		private Builder() {}

		public Builder firstName(String firstName) {
			User.this.firstName = firstName;
			return this;
		}

		public Builder lastName(String lastName) {
			User.this.lastName = lastName;
			return this;
		}

		public Builder email(String email) {
			User.this.email = email;
			return this;
		}

		public Builder userName(String userName) {
			User.this.userName = userName;
			return this;
		}

		public Builder password(String password) {
			User.this.password = password;
			return this;
		}

		public Builder photo(String photo) {
			User.this.photo = photo;
			return this;
		}

		public User build() {
			return User.this;
		}
	}

}
