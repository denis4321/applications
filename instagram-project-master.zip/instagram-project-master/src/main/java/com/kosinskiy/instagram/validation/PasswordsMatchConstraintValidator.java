package com.kosinskiy.instagram.validation;

import com.kosinskiy.instagram.dto.UserRegistrationDto;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PasswordsMatchConstraintValidator implements ConstraintValidator<PasswordsMatch, Object> {
	@Override
	public void initialize(PasswordsMatch constraintAnnotation) {

	}

	@Override
	public boolean isValid(Object object, ConstraintValidatorContext constraintValidatorContext) {
		UserRegistrationDto userRegistrationDto = (UserRegistrationDto) object;
		return userRegistrationDto.getPassword().equals(userRegistrationDto.getPasswordConfirmation());
	}
}
