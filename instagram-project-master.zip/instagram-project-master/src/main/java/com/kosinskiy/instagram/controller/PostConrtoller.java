package com.kosinskiy.instagram.controller;

import com.kosinskiy.instagram.dto.PostDto;
import com.kosinskiy.instagram.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@RestController
@RequestMapping("/post")
public class PostConrtoller {

	@Autowired
	private PostService postService;

	@GetMapping("/{id}")
	public PostDto getPostDto(@PathVariable Long id) {
		return postService.getPostDtoById(id);
	}

	@GetMapping("/{postId}/doLike")
	public void addOrRemoveIfExistLike(Principal principal, @PathVariable Long postId) {
		postService.addOrRemoveIfExistLike(principal, postId);

	}
}
