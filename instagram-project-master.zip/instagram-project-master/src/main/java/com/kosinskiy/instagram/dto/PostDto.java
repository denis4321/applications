package com.kosinskiy.instagram.dto;

import com.kosinskiy.instagram.entity.Comment;
import com.kosinskiy.instagram.entity.Like;
import com.kosinskiy.instagram.entity.User;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class PostDto {

	private long id;
	private Date date;
	private String text;
	private String photo;
	private User user;
	private List<Like> likes;
	private List<Comment> comments;
}
