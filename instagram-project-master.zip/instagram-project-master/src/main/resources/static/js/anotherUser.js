document.addEventListener('DOMContentLoaded', async () => {

    let user = await getAnotherUser(getUsernameFromURL(window.location.href));
    let loggedUser = await getUser();

    redirectIfLoggedUser(user, loggedUser);
    chooseSubscribeButton(user, loggedUser);

    let userFollowers = user.followers;
    let userFollowing = user.following;
    let updatePhotoInputElement = document.getElementById('update-photo-input');
    let createPostPhotoInputElement = document.getElementById('create-post-photo');

    displayUserData(user);
    displayUserList (userFollowers, 'followers-count');
    displayUserList (userFollowing, 'following-count');
    displayPostsBlock(user);

    document.getElementById('followers-button').addEventListener('click',() => displayFollowList(userFollowers, 'followers'));
    document.getElementById('following-button').addEventListener('click', () => displayFollowList(userFollowing, 'following'));
    document.getElementById('user-posts').addEventListener('click',event => fillPostModal(event));

    updatePhotoInputElement.addEventListener('change', () => {
        disableSubmitButton('submit-update-photo');
        checkField(updatePhotoInputElement, 'update-photo-form', 'user/update/photo/validate', 'submit-update-photo')
    });

    document.getElementById('submit-update-photo').addEventListener('click', event => {
        updateUserPhoto(event);
    });

    document.getElementById('edit-profile-form').addEventListener('input', event => {
        disableSubmitButton('submit-update-user');
        setTimeout(checkField, 2000, event.target, 'edit-profile-form','/user/update/validate', 'submit-update-user')
    });

    document.getElementById('edit-profile-form').addEventListener('focusout', event => {
        checkField(event.target, 'edit-profile-form','/user/update/validate', 'submit-update-user')
    });

    document.getElementById('submit-update-user').addEventListener('click', event => {
        updateUser(event);
    });

    createPostPhotoInputElement.addEventListener('change', () => {
        disableSubmitButton('submit-create-post');
        checkField(createPostPhotoInputElement, 'create-post-form', 'post/create/validate', 'submit-create-post')
    });

    document.getElementById('submit-create-post').addEventListener('click', event => {
        createPost(event);
    });

    document.getElementById('navbar-search').addEventListener('input', async () => {
        let formData = getFormData('navbar-search-form');
        let users = await ajaxJsonPOST('user/search', formData);
        console.log(users);
        displaySearchList(users, 'followers');
    });

    document.getElementById('subscribe-button').addEventListener('click', async (event) => {
        doSubscribe(event, user);

    })

});

async function doSubscribe(event, user) {
    event.preventDefault();
    let subscribeButton = document.getElementById('subscribe-button');
    let currentAction = subscribeButton.textContent;
    let response = await fetch(`/user/subscribe/${user.userName}`, {
        credentials: 'same-origin'
    });
    if (response.status === 200) {
        if (currentAction === 'Unsubscribe') {
            removeClassFromElement(subscribeButton, 'btn-danger');
            subscribeButton.innerText = 'Subscribe';
            addClassToElement(subscribeButton, 'btn-success')
        } else {
            removeClassFromElement(subscribeButton, 'btn-success');
            subscribeButton.innerText = 'Unsubscribe';
            addClassToElement(subscribeButton, 'btn-danger')
        }
    }
    window.location.reload(true);
}

function chooseSubscribeButton(user, loggedUser) {
    let subscribeButton = document.getElementById('subscribe-button');
    let isFollowing = loggedUser.following.find(following => following.userName === user.userName);
    if (isFollowing) {
        subscribeButton.innerText = 'Unsubscribe';
        addClassToElement(subscribeButton, 'btn-danger')
    } else {
        subscribeButton.innerText = 'Subscribe';
        addClassToElement(subscribeButton, 'btn-success')
    }

}

function redirectIfLoggedUser(user, loggedUser) {
    if (loggedUser.userName === user.userName) {
        window.location.replace('../');
    }
}

async function createPost(event) {
    event.preventDefault();
    let formData = getFormData('create-post-form');
    let validationResult = await ajaxJsonPOST('/post/create', formData);
    if (validationResult.status === 'successful') {
        window.location.reload(true)
    } else {
        Array.from(document.getElementsByTagName('input')).forEach(input => {
            checkField(input, 'create-post-form','/post/create/validate', 'submit-create-post');
        });
    }
}

async function updateUser(event) {
    event.preventDefault();
    let formData = getFormData('edit-profile-form');
    let validationResult = await ajaxJsonPOST('/user/update', formData);
    if (validationResult.status === 'successful') {
        window.location.reload(true)
    } else {
        Array.from(document.getElementsByTagName('input')).forEach(input => {
            checkField(input, 'edit-profile-form','/user/update/validate', 'submit-update-user');
        });
    }
}

async function updateUserPhoto(event) {
    event.preventDefault();
    let formData = getFormData('update-photo-form');
    let validationResult = await ajaxJsonPOST('/user/update/photo', formData);
    if (validationResult.status === 'successful') {
        window.location.reload(true)
    } else {
        let inputImage = document.getElementById('update-photo-input');
        showErrorMessage(inputImage, validationResult.fieldErrors['photo']);
    }
}

async function fillPostModal(event) {
    let postLink = event.path[1].href;
    let postId = postLink.substring(postLink.search('/post/') + 6);
    let response = await fetch(`post/${postId}`);
    let post = await response.json();

    let postModalImageElement = document.getElementById('post-modal-image');
    postModalImageElement.setAttribute('src', post.photo);

    let postModalLikesElement = document.getElementById('post-modal-likes');
    postModalLikesElement.innerText = `${post.likes.length} likes`;

    let postModalTextElement = document.getElementById('post-modal-text');
    postModalTextElement.innerText = post.text;

    let postModalIdElement = document.getElementById('post-modal-id');
    postModalIdElement.innerText = postId;
}

async function getUser() {
    let response = await fetch(`/user`, {
        credentials: 'same-origin'
    });
    return response.json();
}

async function getAnotherUser(userName) {
    let response = await fetch(`/user/${userName}`, {
        credentials: 'same-origin'
    });
    return response.json();
}

function displayUserData(user) {
    let userPhotoElement = document.getElementById('user-photo');
    userPhotoElement.setAttribute('src', user.photo);

    let userLoginBlock = document.getElementById('user-login');
    userLoginBlock.innerText = user.userName;

    let userNameBlock = document.getElementById('user-name');
    userNameBlock.innerText = `${user.firstName} ${user.lastName}`;

    let postCountElement = document.getElementById('post-count');
    postCountElement.innerText = user.posts.length;
}

function displayUserList(followers, followElementId) {
    let followElement = document.getElementById(followElementId);
    followElement.innerHTML = followers.length;
}

function displayPostsBlock(user) {
    let posts = user.posts;
    let count = 0;

    let userPostsElement = document.getElementById('user-posts');


    let postRowElement = document.createElement('div');
    postRowElement.setAttribute('class', 'row mb-4');
    userPostsElement.append(postRowElement);


    posts.sort((post1, post2) => new Date(post2.date) - new Date(post1.date));
    posts.forEach(post => {
        if (count%3 === 0) {
            postRowElement = document.createElement('div');
            postRowElement.setAttribute('class', 'row mb-4');
            userPostsElement.append(postRowElement);
        }
        count++;
        let imageLinkElement = document.createElement('a');
        imageLinkElement.setAttribute('class', 'col-4 post-modal-button');
        imageLinkElement.setAttribute('href', `/post/${post.id}`);
        imageLinkElement.setAttribute('data-toggle', 'modal');
        imageLinkElement.setAttribute('data-target', '#post-modal');


        let imageElement = document.createElement('img');
        imageElement.setAttribute('class', 'img-fluid post-image');
        imageElement.setAttribute('src', post.photo);
        imageLinkElement.append(imageElement);
        postRowElement.append(imageLinkElement);
    });
}

function displayFollowList(followList, type) {
    let followersBodyElement = document.getElementById(`${type}-modal-body`);
    let isFilled = followersBodyElement.children.length > 0;
    followList.forEach(follower => {
        if(!isFilled) {
            let followDivElement = document.createElement('a');
            followDivElement.setAttribute('class', 'mb-2 d-block text-dark');
            followDivElement.setAttribute('href', `/anotherUser.html?user/${follower.userName}`);


            let followImageElement = document.createElement('img');
            followImageElement.setAttribute('src', follower.photo);
            followImageElement.setAttribute('class', `${type}-modal-image img-fluid rounded-circle mr-3`);

            let followUsernameElement = document.createElement('span');
            followUsernameElement.innerText = follower.userName;

            followDivElement.append(followImageElement);
            followDivElement.append(followUsernameElement);
            followersBodyElement.append(followDivElement);
        }
    });
}

function displaySearchList(searchList, type) {
    let followersBodyElement = document.getElementById(`navbar-search-body`);
    followersBodyElement.style.display = 'block';
    followersBodyElement.innerHTML = '';
    searchList.forEach(user => {
        let followDivElement = document.createElement('div');
        followDivElement.setAttribute('class', 'mb-2');


        let followImageElement = document.createElement('img');
        followImageElement.setAttribute('src', user.photo);
        followImageElement.setAttribute('class', `${type}-modal-image img-fluid rounded-circle mr-3`);

        let followUsernameElement = document.createElement('span');
        followUsernameElement.innerText = user.userName;

        followDivElement.append(followImageElement);
        followDivElement.append(followUsernameElement);
        followersBodyElement.append(followDivElement);

    });
}

function getUsernameFromURL(url) {
    return url.substring(url.lastIndexOf('/')+1)
}