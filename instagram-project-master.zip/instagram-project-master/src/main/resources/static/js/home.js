document.addEventListener('DOMContentLoaded', function(){

    getPostData()

});

function getPostData() {

    let promise = fetch('/user');
    promise.then(function (response) {
        return response.json();
    }).then(function (user) {
        console.log(user);
        showPosts(user.following)
    });
}

function showPosts(following) {

    let container = document.getElementsByClassName('container')[0];

    following.forEach(user => {

        let posts = user.posts;

        posts.forEach(post => {
            let postDiv = document.createElement('div');
            postDiv.setAttribute('class', 'post');

            let postImage = document.createElement('img');
            postImage.setAttribute('class', 'post-image');
            postImage.setAttribute('src', post.photo);

            let postText = document.createElement('p');
            postText.setAttribute('class', 'post-text');
            postText.innerHTML = post.text;

            let postLikes = document.createElement('p');
            postLikes.setAttribute('class', 'post-likes');
            postLikes.innerHTML = post.likes.length + ' likes!';

            postDiv.append(postImage);
            postDiv.append(postText);
            postDiv.append(postLikes);

            container.appendChild(postDiv)
        });
    });

}